from contextlib import asynccontextmanager
from fastapi import FastAPI
from app.api.routes import router as api_router
from app.core.config import settings
from app.core.logging_config import setup_logging
from app.services.llm_service import LLMService

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Load the LLM model
    app.state.llm_service = LLMService()
    yield
    # Clean up the LLM model and release the resources
    del app.state.llm_service

app = FastAPI(title="Text2Sql API", lifespan=lifespan)

app.include_router(api_router, prefix="/api")
setup_logging()

if __name__ == "__main__":
    import uvicorn
    # Ensure the model is downloaded before starting the server
    LLMService()._get_model_path()

    uvicorn.run(
        "main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG_MODE
    )