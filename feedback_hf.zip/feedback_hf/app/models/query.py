from pydantic import BaseModel
from typing import Any, List, Union

class QueryRequest(BaseModel):
    sql_query: str

class QueryResponse(BaseModel):
    success: bool
    result: Union[List[Any], str]
