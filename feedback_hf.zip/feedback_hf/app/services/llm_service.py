import os
from pathlib import Path
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from langchain.prompts import PromptTemplate
from app.core.logging_config import get_logger
from app.core.templates import TEMPLATE_TABLE_MISSING_FEEDBACK, TEMPLATE_GENERAL
from typing import Dict

logger = get_logger(__name__)

class LLMService:
    def __init__(self):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model_name = "ibm-granite/granite-8b-code-instruct"
        self.model_path = self._get_model_path()
        self.tokenizer = self._load_tokenizer()
        self.model = self._load_model()
        self.model.eval()
        self.feedback_templates: Dict[str, PromptTemplate] = {
            "table_missing": PromptTemplate.from_template(TEMPLATE_TABLE_MISSING_FEEDBACK),
            "general": PromptTemplate.from_template(TEMPLATE_GENERAL)
        }

    def _get_model_path(self):
        project_root = Path(__file__).parents[2]  # Adjust this based on your actual file structure
        return project_root / "ml_models" / self.model_name.split('/')[-1]

    def _load_tokenizer(self):
        if (self.model_path / "tokenizer_config.json").exists():
            logger.info(f"Loading tokenizer from {self.model_path}")
            return AutoTokenizer.from_pretrained(str(self.model_path), local_files_only=True)
        else:
            logger.info(f"Tokenizer not found locally. Downloading from {self.model_name}...")
            tokenizer = AutoTokenizer.from_pretrained(self.model_name)
            tokenizer.save_pretrained(str(self.model_path))
            logger.info(f"Tokenizer saved to {self.model_path}")
            return tokenizer

    def _load_model(self):
        if (self.model_path / "config.json").exists():
            logger.info(f"Loading model from {self.model_path}")
            return AutoModelForCausalLM.from_pretrained(str(self.model_path), device_map=self.device, low_cpu_mem_usage=True)
        else:
            logger.info(f"Model not found locally. Downloading from {self.model_name}...")
            model = AutoModelForCausalLM.from_pretrained(self.model_name, device_map=self.device, low_cpu_mem_usage=True)
            model.save_pretrained(str(self.model_path))
            logger.info(f"Model saved to {self.model_path}")
            return model

    async def get_feedback(self, sql_query: str, error: str) -> str:
        """
        Get feedback on the SQL query based on the error.
        """
        error_type = self._classify_error(error)
        template = self.feedback_templates.get(error_type, self.feedback_templates["general"])
        prompt = template.format(sql_query=sql_query, error=error)
        chat = [
            {"role": "user", "content": prompt},
        ]
        chat = self.tokenizer.apply_chat_template(chat, tokenize=False, add_generation_prompt=True)
        input_tokens = self.tokenizer(chat, return_tensors="pt").to(self.device)
        with torch.no_grad():
            output = self.model.generate(**input_tokens, max_new_tokens=100)
        corrected_query = self.tokenizer.batch_decode(output)[0]
        logger.info(f"LLM feedback: Original query: {sql_query}, Corrected query: {corrected_query}")
        return corrected_query

    def _classify_error(self, error: str) -> str:
        """
        Classify the error type.
        """
        if error:
            return "table_missing"
        return "general"