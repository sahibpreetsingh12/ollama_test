from typing import Any, List
import mysql.connector
from mysql.connector import Error
from app.core.config import Settings
from app.services.llm_service import LLMService
from app.core.logging_config import get_logger

logger = get_logger(__name__)

class QueryService:
    def __init__(self, settings: Settings, llm_service: LLMService):
        self.settings = settings
        self.llm_service = llm_service

    async def execute_query(self, sql_query: str) -> List[Any]:
        """
        Execute the given SQL query.

        Args:
            sql_query (str): The SQL query to execute.

        Returns:
            List[Any]: The result of the query execution.

        Raises:
            Exception: If there's an error connecting to the database or executing the query.
        """
        connection = self._connect_to_mysql()
        if not connection:
            raise Exception("Failed to connect to MySQL database")

        try:
            with connection.cursor() as cursor:
                cursor.execute(sql_query)
                return cursor.fetchall()
        finally:
            connection.close()

    async def get_corrected_query(self, sql_query: str) -> str:
        """
        Attempt to get a corrected version of the SQL query.

        Args:
            sql_query (str): The original SQL query.

        Returns:
            str: The corrected SQL query.
        """
        try:
            await self.execute_query(sql_query)
            return sql_query
        except Exception as e:
            return await self.llm_service.get_feedback(sql_query, str(e))

    def _connect_to_mysql(self) -> mysql.connector.connection.MySQLConnection:
        """
        Establish a connection to the MySQL database.

        Returns:
            mysql.connector.connection.MySQLConnection: The database connection object.

        Raises:
            Error: If there's an error connecting to the database.
        """
        try:
            connection = mysql.connector.connect(
                host=self.settings.DB_HOST,
                user=self.settings.DB_USER,
                password=self.settings.DB_PASSWORD,
                database=self.settings.DB_NAME
            )
            if connection.is_connected():
                logger.info("Connected to MySQL database")
                return connection
        except Error as e:
            logger.error(f"Error while connecting to MySQL: {str(e)}")
            raise
        return None