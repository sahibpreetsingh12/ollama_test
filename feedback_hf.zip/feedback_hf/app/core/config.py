from pydantic_settings import BaseSettings
from functools import lru_cache

class Settings(BaseSettings):
    DB_HOST: str
    DB_USER: str
    DB_PASSWORD: str
    DB_NAME: str
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    DEBUG_MODE: bool = True
    MAX_FEEDBACK_ATTEMPTS: int = 3

    class Config:
        env_file = ".env"

settings = Settings()

@lru_cache()
def get_settings() -> Settings:
    return Settings()