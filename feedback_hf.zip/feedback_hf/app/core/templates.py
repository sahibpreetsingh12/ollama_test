TEMPLATE_TABLE_MISSING_FEEDBACK = """
You are a helpful data engineer with good knowledge of MySQL. You are provided with an SQL query, error, and schema of the table.
# mysql_query: {sql_query}
# error: {error}
# schema:

CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Email VARCHAR(100),
    Department VARCHAR(50),
    Position VARCHAR(50),
    Salary DECIMAL(10, 2)
);

CREATE TABLE EmployeeDetails (
    EmployeeID INT PRIMARY KEY,
    BirthDate DATE,
    Address VARCHAR(100),
    City VARCHAR(50),
    State VARCHAR(50),
    ZipCode VARCHAR(20),
    Phone VARCHAR(20),
    FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID)
);

Here error is about table does not exist in the database. Check sql_query with schema and return a correct SQL query. Check the name of the table mentioned in sql_query with schema table and correct it.

```sql

"""

TEMPLATE_GENERAL = """
Write a MySQL query to answer the following question given the database schema. Please wrap your code answer using ```:

Schema:

CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Email VARCHAR(100),
    Department VARCHAR(50),
    Position VARCHAR(50),
    Salary DECIMAL(10, 2)
);

CREATE TABLE EmployeeDetails (
    EmployeeID INT PRIMARY KEY,
    BirthDate DATE,
    Address VARCHAR(100),
    City VARCHAR(50),
    State VARCHAR(50),
    ZipCode VARCHAR(20),
    Phone VARCHAR(20),
    FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID)
);

Question: `{question}`:
```sql
"""
