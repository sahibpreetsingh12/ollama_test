from fastapi import APIRouter, Depends, Request
from app.models.query import QueryRequest, QueryResponse
from app.services.query_service import QueryService
from app.services.llm_service import LLMService
from app.core.logging_config import get_logger
from app.core.config import Settings, get_settings

router = APIRouter()
logger = get_logger(__name__)

def get_llm_service(request: Request) -> LLMService:
    return request.app.state.llm_service

def get_query_service(
    settings: Settings = Depends(get_settings),
    llm_service: LLMService = Depends(get_llm_service)
) -> QueryService:
    return QueryService(settings=settings, llm_service=llm_service)

@router.post("/feedback", response_model=QueryResponse)
async def feedback(
    request: QueryRequest,
    query_service: QueryService = Depends(get_query_service)
) -> QueryResponse:
    """
    Generate a response for the given SQL query.
    Args:
    request (QueryRequest): The request containing the SQL query.
    query_service (QueryService): The query service for executing SQL queries.
    Returns:
    QueryResponse: The response containing the query result or error message.
    """
    try:
        result = await query_service.execute_query(request.sql_query)
        return QueryResponse(success=True, result=result)
    except Exception as e:
        logger.error(f"Error executing query: {str(e)}")
        return await feedback_loop(request, query_service)

async def feedback_loop(
    request: QueryRequest,
    query_service: QueryService,
    attempt: int = 0
) -> QueryResponse:
    """
    Attempt to correct and re-execute the SQL query.
    Args:
    request (QueryRequest): The request containing the SQL query.
    query_service (QueryService): The query service for executing SQL queries.
    attempt (int): The current attempt number.
    Returns:
    QueryResponse: The response containing the query result or error message.
    """
    settings = query_service.settings
    if attempt >= settings.MAX_FEEDBACK_ATTEMPTS:
        return QueryResponse(success=False, result="I need some time to figure this out.")
    try:
        corrected_query = await query_service.get_corrected_query(request.sql_query)
        result = await query_service.execute_query(corrected_query)
        return QueryResponse(success=True, result=result)
    except Exception as e:
        logger.warning(f"Feedback attempt {attempt + 1} failed: {str(e)}")
        return await feedback_loop(QueryRequest(sql_query=corrected_query), query_service, attempt + 1)