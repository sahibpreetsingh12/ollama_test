import sys
import os
import pytest
from httpx import AsyncClient
from fastapi import FastAPI
from unittest.mock import MagicMock
from app.api.routes import router
from app.services.query_service import QueryService

# Create a test app
app = FastAPI()
app.include_router(router)

# Mock the query service
@pytest.fixture
def mock_query_service(mocker):
    mock_service = mocker.patch('app.api.routes.QueryService', autospec=True)
    mock_service.return_value.settings = MagicMock()
    mock_service.return_value.settings.MAX_FEEDBACK_ATTEMPTS = 3
    return mock_service

@pytest.mark.asyncio
async def test_feedback_successful_query(mock_query_service):
    # Set up the mock to return a successful result
    mock_query_service.return_value.execute_query.return_value = "Query result for EmployeeDetails"

    async with AsyncClient(app=app, base_url="http://test") as ac:
        # Send a POST request to the /feedback endpoint
        response = await ac.post("/feedback", json={"sql_query": "SELECT * FROM EmployeeDetails"})

    # Check if the response is as expected
    assert response.status_code == 200
    assert response.json() == {"success": True, "result": "Query result for EmployeeDetails"}

    # Verify that execute_query was called with the correct argument
    mock_query_service.return_value.execute_query.assert_called_once_with("SELECT * FROM EmployeeDetails")

@pytest.mark.asyncio
async def test_feedback_query_error_and_correction(mock_query_service):
    # Set up the mock to raise an exception and then return a corrected result
    mock_query_service.return_value.execute_query.side_effect = [
        Exception("Table 'non_existent_table' doesn't exist"),
        "Corrected result for EmployeeDetails"
    ]
    
    # Mock the corrected query
    mock_query_service.return_value.get_corrected_query.return_value = "SELECT * FROM EmployeeDetails"

    async with AsyncClient(app=app, base_url="http://test") as ac:
        # Send a POST request to the /feedback endpoint
        response = await ac.post("/feedback", json={"sql_query": "SELECT * FROM non_existent_table"})

    # Check if the response is as expected
    assert response.status_code == 200
    assert response.json() == {"success": True, "result": "Corrected result for EmployeeDetails"}

    # Verify that get_corrected_query and execute_query were called
    mock_query_service.return_value.get_corrected_query.assert_called_once()
    assert mock_query_service.return_value.execute_query.call_count == 2
    mock_query_service.return_value.execute_query.assert_called_with("SELECT * FROM EmployeeDetails")

@pytest.mark.asyncio
async def test_feedback_query_error_max_attempts(mock_query_service):
    # Set up the mock to always raise an exception
    mock_query_service.return_value.execute_query.side_effect = Exception("Table 'non_existent_table' doesn't exist")
    
    # Mock the corrected query
    mock_query_service.return_value.get_corrected_query.return_value = "SELECT * FROM EmployeeDetails"

    async with AsyncClient(app=app, base_url="http://test") as ac:
        # Send a POST request to the /feedback endpoint
        response = await ac.post("/feedback", json={"sql_query": "SELECT * FROM non_existent_table"})

    # Check if the response indicates the maximum attempts were reached
    assert response.status_code == 200
    assert response.json() == {"success": False, "result": "I need some time to figure this out."}

    # Verify that get_corrected_query and execute_query were called multiple times
    
    assert mock_query_service.return_value.execute_query.call_count == 4  # 3 attempts total = 1 try and 3 reattempts

# Add more tests as needed