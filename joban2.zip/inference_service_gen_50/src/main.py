# from fastapi import FastAPI
# import requests, os
# from services.libs.config import ConfigService
# import logging.config
# import logging
# from models.endpointModels import LLMInferenceRequest, LLMInferenceResponse
# from utils.sqlModelInference import SQLInference

# # Load the logging configuration
# log_config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logging.conf')
# logging.config.fileConfig(log_config_path, disable_existing_loggers=False)
# logger = logging.getLogger('fastapi')

# # Create FastAPI app
# app = FastAPI(title="Inference Service")
# sql_inference = SQLInference()

# # Initialize ConfigService
# config_service = ConfigService()
# config_service.load_config_from_mongo()

# # Define route handlers
# @app.get("/health", tags=["healthcheck"])
# def health():
#     logger.info("Health check endpoint was called.")
#     return {"status": "Inference Service is healthy"}

# @app.get("/", tags=["healthcheck"])
# def index():
#     some_key_value = config_service.get('some_key')
#     logger.info(f"Index endpoint was called. Retrieved config for 'some_key': {some_key_value}")
#     return {"message": f"Hello from Inference Service! Config: {some_key_value}"}

# # TODO: Move to routes according to project structure
# @app.get("/generateSQLQuery",tags=["inference"], response_model=LLMInferenceResponse)
# def generateSQLQuery(request_parameters:LLMInferenceRequest):
#     user_query = request_parameters.sql_query
#     sql_query = sql_inference.generate_sql_query(user_query)
#     return sql_query

# @app.get("/regenerateSQLQuery",tags=["inference"])
# def regenerate_sql_query(sql_error,erroneous_sql_query):        # Feedback loop
#     improved_sql_query = sql_inference.regenerate_sql_query(sql_error,erroneous_sql_query)
#     return improved_sql_query

# # Register service
# config_service.register_service('inference-service', 5004)
# logger.info("Inference Service has been registered with config service.")

# # Additional logging if needed
# logger.info("Inference Service has started.")


######
from fastapi import FastAPI, Depends
from src.core.config import Settings, get_settings
import logging.config
import logging
from src.models.endpointModels import LLMInferenceRequest, LLMInferenceResponse, RegenerateSQLRequest
from src.utils.sqlModelInference import SQLInference
import sqlparse

# Load the logging configuration
logging.config.fileConfig('logging.conf', disable_existing_loggers=False)
logger = logging.getLogger('fastapi')

app = FastAPI(title="Inference Service")
sql_inference = SQLInference()

@app.get("/health", tags=["healthcheck"])
def health():
    logger.info("Health check endpoint was called.")
    return {"status": "Inference Service is healthy"}

@app.get("/", tags=["healthcheck"])
def index(settings: Settings = Depends(get_settings)):
    logger.info(f"Index endpoint was called. Debug mode: {settings.DEBUG_MODE}")
    return {"message": f"Hello from Inference Service! Debug mode: {settings.DEBUG_MODE}"}

@app.post("/generateSQLQuery", tags=["inference"], response_model=LLMInferenceResponse)
async def generate_sql_query(request: LLMInferenceRequest, settings: Settings = Depends(get_settings)):
    sql_query = await sql_inference.generate_sql_query(request.user_query)
    print(sql_query)
    #sql_query = sqlparse.format(sql_query,reindent =True)
    # a= LLMInferenceResponse(sql_query=sql_query)
    # print(sql_query , type(sql_query))
    # return LLMInferenceResponse(sql_query=sql_query)
    sql_query =str(sql_query)
    print(sql_query)
    return LLMInferenceResponse(sql_query=sql_query)
    #return sql_query

@app.post("/regenerateSQLQuery", tags=["inference"], response_model=LLMInferenceResponse)
async def regenerate_sql_query(request: RegenerateSQLRequest, settings: Settings = Depends(get_settings)):
    improved_sql_query = await sql_inference.regenerate_sql_query(request.sql_error, request.erroneous_sql_query)
    #improved_sql_query = sqlparse.format(improved_sql_query)
    # a= LLMInferenceResponse(sql_query=improved_sql_query)
    # print(improved_sql_query , type(improved_sql_query))
    # return LLMInferenceResponse(sql_query=improved_sql_query)
    return improved_sql_query

if __name__ == "__main__":
    import uvicorn
    settings = get_settings()
    uvicorn.run(
        "app:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG_MODE
    )

logger.info("Inference Service has started.")
