# from pydantic import BaseModel, constr
# from pydantic_settings import BaseSettings

# class LLMInferenceRequest(BaseModel):
#     user_query: str
#     llm_model: str = "ibm-granite/granite-8b-code-base"          #TODO: Add this value to config
#     device: str = "cuda" # CPU

# class LLMInferenceResponse(BaseModel):
#     sql_query: str

# class RegenerateSQLRequest(BaseModel):
#     sql_error: constr(max_length=40)

# class Settings(BaseSettings):
#     SQL_MODEL_NAME: str
#     HARDWARE_DEVICE: str        #CPU/GPU
#     DEBUG_MODE: bool = True

#     class Config:
#         env_file = ".env"

# settings = Settings()



from pydantic import BaseModel, constr,Field
from pydantic_settings import BaseSettings


class LLMInferenceRequest(BaseModel):
    user_query: str
    llm_model: str = "ibm-granite/granite-8b-code-instruct"
    device: str = "cuda"

class LLMInferenceResponse(BaseModel):
    sql_query: str

class RegenerateSQLRequest(BaseModel):
    sql_error: str = Field(..., max_length=40)
    erroneous_sql_query: str
    
# class Settings(BaseSettings):
#     SQL_MODEL_NAME: str = "ibm-granite/granite-3b-code-instruct"
#     HARDWARE_DEVICE: str = "cuda"
#     DEBUG_MODE: bool = True
#     MAX_FEEDBACK_ATTEMPTS: int = 3

#     class Config:
#         env_file = ".env"

# settings = Settings()