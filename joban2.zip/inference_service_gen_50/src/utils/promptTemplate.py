# from pydantic import BaseModel, Field, constr

# class PromptTemplate(BaseModel):
#     table_schema: constr(strip_whitespace=True, min_length=1)
#     user_query: constr(strip_whitespace=True, min_length=1)
#     available_sql_query: constr(strip_whitespace=True, min_length=1)
#     sql_error: constr(strip_whitespace=True, min_length=1)

#     @property
#     def generate_sql_query_template(self):
#         generate_sql_query = f"""
#         Write a MySQL query to answer the following question given the database schema. Please wrap your code answer using ```:

#         Schema: `{self.table_schema}`

#         Question: `{self.user_query}`:
#         ```sql
#         """
#         return generate_sql_query
    
#     @property
#     def regenerate_error_sql_query_template(self):       #feedback loop
#         regenerate_sql_query =  f"""
#         You are a helpful data engineer with good knowledge of relational SQL databases. You are provided with an SQL query, error, and schema of the table.
#         sql_query: {self.available_sql_query}
#         error: {self.sql_error}
#         schema: {self.table_schema}
#         """
#         return regenerate_sql_query


from pydantic import BaseModel, Field
from typing import Optional


class PromptTemplate(BaseModel):
    table_schema: str = Field(..., min_length=1)
    #user_query: str = Field(..., min_length=1)
    user_query: Optional[str] = None
    available_sql_query: Optional[str] = Field(None, min_length=1)
    sql_error: Optional[str] = Field(None, min_length=1)

    def generate_sql_query_template(self) -> str:
        return f"""
        Write a MySQL query to answer the following question given the database schema. Please wrap your code answer using ```:
        Schema: `{self.table_schema}`
        Question: `{self.user_query}`:
        ```sql
        """

    def regenerate_error_sql_query_template(self) -> str:
        return f"""
        You are a helpful data engineer with good knowledge of MySQL. You are provided with an SQL query, error, and schema of the table.
        sql_query: {self.available_sql_query}
        error: {self.sql_error}
        schema: {self.table_schema}

        Here error is about table does not exist in the database. Check sql_query with schema and return a correct SQL query. Check the name of the table mentioned in sql_query with schema table and correct it.

        ```sql
        """
